import tkinter as tk
import _thread
import sys

def win2_help():
    win2 = tk.Toplevel()
    win2.geometry("400x300")
    win2.resizable(False, False)
    # tk.Label(win2, image=tk.PhotoImage(file="tedix.gif")).grid(row=0)
    tk.Label(win2, text="Tedix").grid(row=1)
    tk.Label(win2, text="Author: Joulier429").grid(row=2)

rtwin = tk.Tk()

rtwin.title("Tedix")
rtwin.geometry("400x300")

mainmenu = tk.Menu(rtwin)

filemenu = tk.Menu(mainmenu, tearoff=False)
filemenu.add_command(label="新建")
filemenu.add_command(label="保存")
filemenu.add_command(label="另存为")
filemenu.add_separator()
filemenu.add_command(label="退出", command=sys.exit)
mainmenu.add_cascade(label="文件", menu=filemenu)
mainmenu.add_command(label="关于", command=win2_help)

textarea = tk.Text(rtwin)
textarea.place(x=0, y=0)
# subtextarea = tk.Text()
# textarea.place(x=0, y=0)

def make_size_of_software():
    while True:
        rtwin.update()
        windowheight = rtwin.winfo_height()
        windowwidth = rtwin.winfo_width()# 
        windowheight = int(windowheight/13.5)
        windowwidth = int(windowwidth/10)
        textarea.config(height=windowheight, width=windowwidth)

_thread.start_new_thread(make_size_of_software, ())

rtwin.config(menu=mainmenu)
rtwin.mainloop()
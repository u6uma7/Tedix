# Tedix

---

## 你好，这里是Joulier429

Tedix大概是一个文本编辑器  
使用起来应该很简单  
名字来源于`Text Edit`  
如果两个单词所有字母都只能出现一遍  
就得到了`Texdi`  
再将`x`和`di`交换一下位置  
就得到了`Tedix`

[开源地址](https://github.com/jlr429/Tedix/)
